# Regras padrão
